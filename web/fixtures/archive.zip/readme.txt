files.gg fixture archive.
